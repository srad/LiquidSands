Thank you for downloading:

UI Buttons and Whooshes Pack 1

If you find these files useful, please consider linking back to my web-site, or donating a small amount. Anything would be appreciated greatly! If re-distributing this pack, please keep this readme as is.
Remember to check back at my site for more freebies and downloads.

http://www.narfstuff.co.uk
Paypal address: fran@narfstuff.co.uk

--------------------------------
70 Files
--------------------------------

Stereo PCM .wav

Bit Rate    : 1411kbps

Audio
Sample size : 16bit

Audio
Sample rate : 44khz

--------------------------------

From http://www.narfstuff.co.uk/

Please direct comments and questions to:
fran@narfstuff.co.uk


Licence
-------

-You may use these files in any commercial or personal project, as many times as you like!
-You may not resell, give away, or redistribute these files verbatim. That would be unfair! : )
